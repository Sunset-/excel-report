import Vue from "vue";

import DagTree from "./tree";
import Coder from "./coder/index.vue";
import ResourcesSelect from "./resourcesSelect";
import ResourcesModal from "./resourcesModal";

Vue.component("DagTree", DagTree);
Vue.component("xui-coder",Coder);
Vue.component("ResourcesSelect", ResourcesSelect);
Vue.component("ResourcesModal", ResourcesModal);