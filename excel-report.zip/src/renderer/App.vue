<template>
    <div id="app" class="MODULE-CONTAINER" style="min-width:1200px;">
        <router-view></router-view>
    </div>
</template>

<script>
export default {
    name: "dag-component-devtools"
};
</script>

<style>
/* CSS */
</style>
