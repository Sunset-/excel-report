import jsonview from "./jsonview.js";
import "./jsonview.css";
import "./style.less";

export default (window.$jsonview = jsonview);
